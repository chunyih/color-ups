$("img").click( function(){
    window.location = 'L1.html';
    return false;
});

$(".goback").click( function(){
    window.location = 'index.html';
    return false;
});

$(".brandLogo").click( function(){
    window.location = 'index.html';
    return false;
});