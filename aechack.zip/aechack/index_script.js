$("img").click( function(){
    window.location = 'master.html';
    return false;
});