$('div.weightBtn').click(function() {
  window.location = 'weight.html';
  return false;
});
$('div.pressureBtn').click(function() {
  window.location = 'pressure.html';
  return false;
});
$('div.rateBtn').click(function() {
  window.location = 'rate.html';
  return false;
});
$('div.oxyBtn').click(function() {
  window.location = 'oxy.html';
  return false;
});
$('div.chat').click(function() {
  window.location = 'chat.html';
  return false;
});
$('div.title').click(function() {
  window.location = 'index.html';
  return false;
});